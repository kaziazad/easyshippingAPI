<?php

echo "string";