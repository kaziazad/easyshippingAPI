<?php
/**
 * Plugin Name: KAA Shipping API
 * Plugin URI: http://www.kazimahmu.com/kaa-shipping-api
 * Description: Realtime shipping calculation of international market. It's included large number of available shipping company. 
 * Version: 1.0
 * Author: Kazi Mahmud Al Azad
 * Author URI: http://www.kazimahmud.com
 */


if ( ! defined( 'ABSPATH' ) ) {
	return;
}

require_once(dirname(__FILE__).'/lib/codestar-framework/codestar-framework.php');


class MAA_Shipping_API{


    public function __construct(){

        add_action('wp_enqueue_scripts', array( $this,'maa_shipping_style'));
       



    }

    function maa_shipping_style(){
        wp_enqueue_style('bootstap', plugins_url('/assets/css/bootstrap.min.css', __FILE__));
        wp_enqueue_style('customstyle', plugins_url('/assets/css/style.css',__FILE__));
        wp_enqueue_style('fontawosom', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css');
    
        wp_enqueue_script('jquery-shipping', plugins_url('/assets/js/jquery-3.6.js', __FILE__), array(), '', true);
        wp_enqueue_script('customscript-shipping', plugins_url('/assets/js/scripts.js', __FILE__), array("jquery-shipping"), '', true);
    
    }

    public function shortcode(){
        add_shortcode('maa-shipping-api-form', array($this, 'maa_shipping_api' ));
        add_shortcode('maa-shipping-lists', array($this, 'maa_shipping_lists' ));
    }


    function maa_shipping_api(){

        ob_start();?>
    
    <div class="container col-sm-12 col-md-12 col-lg-9 col-xl-10 shipping-query">
            <h1 class="form-title text-center p-2 mb-3">Shipping Rates</h1>

            <form action="#" id="rate_query">
                <div class="row g-3">
                    <div class="col mt-3 mb-3">
                        <label for="">Shipping Form <select class="origin-country" id="origin_country" value="select" required>
                        
                        </select></label>
                    </div>
                </div>

                <div class="row g-3">
                    <div class="col mt-3 mb-3">
                        <label for="">To <select class="destination-country" id="destination_country" value="select" required>
                        
                        </select></label>
                    </div>
                </div>

                <div class="row g-3">
                    <div class="col-8 mt-3 mb-3">
                        
                        <label for="">Percel Weight</label>
                        <input type="number" name="percel-weight" id="percel_weight" value="1" required>

                    </div>
                    <div class="col-4 mt-3 mb-3">
                        
                        <label class="label-visiblity" for=""><span>Choose Weight Unit</span> <select class="percel-weight-unit" id="percel_weight_unit" value="select">
                            <option  value disabled="disabled">Choose Weight Unit</option>
                            <option selected value="kg">kg</option>
                            <option value="lbs">lbs</option>
                        </select></label>

                    </div>
                  
               </div>
                
                <div class="row g-3 input-group mb-3">

                   
                        
                       
                            <div class="col-8 input-group-prepend">
                                <label for="">Dimensions</label>
                                <input type="number" name="percel-length" id="percel_length" value="10" required>
                                <span>X</span>
                                <input type="number" name="percel-width" id="percel_width" value="5" required>
                                <span>X</span>
                                <input type="number" name="percel-height" id="percel_height" value="5" required>
                            </div>
                            <div class="col-4">

                            <label class="label-visiblity" for=""><span>Choose Weight Unit</span>
                                <select class="percel-dimensions-unit" id="percel_dimensions_unit" value="select">
                                    <option value disabled="disabled">Choose Dimensions Unit</option>
                                    <option selected value="cm">cm</option>
                                    <option value="in">in</option>
                                </select>
                            </label>
                            </div>
                       
    
                    
                    
                </div>
                <div class="row g-3">

   

                    <div class="col-12">
                            
                        <label for="">Products Category </label>
                        <select class="percel-categories-unit" id="percel_categories_unit" value="select">
                                
                            </select>

                    </div>
                </div>
              
               <div class="col mt-3 mb-3 text-center">
                        
                    <input class="btn-rate" type="submit" value="Calculate" id="submit_button"> 

               </div>

                
               
               
            

            </form>
        
         
         
       
    </div>
        
    
    
        <?php return ob_get_clean();
    }


    function maa_shipping_lists(){
        ob_start();?>

        <div class="container col-sm-12 col-md-12 col-lg-9 col-xl-10 shipping-list-area">
            <div class="shipping-lists" id="shipping_lists">
                <table class="table">
                    <thead>
                        <tr>
                        <th scope="col logo-area">Courier</th>
                        <th scope="col">Delivery Time</th>
                        <th scope="col">Tracking</th>
                        <th scope="col">Rating</th>
                        <th scope="col">Service Options</th>
                        <th scope="col">Total Cost</th>
                        </tr>
                    </thead>
                    <tbody id="tbody_id">
                       
                    </tbody>
                </table>
      
            </div>
             <div class="loading-area" id="loading_area">
                
                <div class="spinner-4 hidden" id="loading_spinner"></div>
                  
            </div>
             <div class="notice-area" id="notice_area">
                
              <p>* This is just an estimate. The final price may vary depending on parcel dimensions, insurance etc. <a href="/contact-us">Contact us</a> to see the full landed cost.</p>
                  
            </div>
         
        </div>
       



        <?php return ob_get_clean();

    }
    
   
    
}



if(class_exists('MAA_Shipping_API')){
$maa_shipping_api =  new MAA_Shipping_API();
$maa_shipping_api->shortcode();



// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {

    //
    // Set a unique slug-like ID
    $prefix = 'maa_shipping_api';
  
    //
    // Create options
    CSF::createOptions( $prefix, array(
      'menu_title' => 'MAA Shippping API Options',
      'menu_slug'  => 'maa-shipping-api-settings',
      'framework_title'         => 'MAA Shippping API<small> by <a href="https://kazimahmud.com"> Azad</a></small>',
      'footer_text'             => 'Thanks and stay connect with us',
    ) );
  
    //
    // Create a section
    CSF::createSection( $prefix, array(
      'title'  => 'Shortcode',
      
      'fields' => array(
  
        //
        // A text field

        array(
            'id'         => 'maa-shipping-api-shortcode',
            'type'       => 'text',
            'title'      => 'Shortcode for Query Form',
            'default'    => '[maa-shipping-api-form]',
            'attributes' => array(
              'readonly' => 'readonly',
            ),
        
        ),
        array(
            'id'         => 'maa-shipping-list-shortcode',
            'type'       => 'text',
            'title'      => 'Shortcode for Query Result',
            'default'    => '[maa-shipping-lists]',
            'attributes' => array(
              'readonly' => 'readonly',
            ),
        
        ),
  
      )
    ) );
  
   
  }




}


 

