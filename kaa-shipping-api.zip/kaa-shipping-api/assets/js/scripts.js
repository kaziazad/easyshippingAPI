jQuery(document).ready(function($){

  $(".container").ready(
    function(){

      const loadingSpinner = document.getElementById("loading_spinner");
      // query start
      
      $( "#rate_query" ).on( "submit", function( event ) {
        event.preventDefault();
        loadingSpinner.classList.remove("hidden");
        var originC = $('#origin_country').val();
        var desti = $('#destination_country').val();
        
        var percelL = $("#percel_length").val();
        var percelH = $("#percel_height").val();
        var percelW = $("#percel_width").val();
        var percelDU = $("#percel_dimensions_unit").val();
        var percelWt = $("#percel_weight").val();
        var percelWU = $("#percel_weight_unit").val();
        var percelCU = $("#percel_categories_unit").val();

      // alert(percelWU);
       

       
        
      const options = {
        method: 'POST',
        headers: {
          accept: 'application/json',
          'content-type': 'application/json',
          authorization: 'Bearer prod_vYG+WAAzcUI1YS6WUtm3FdxfPONsbqdHoyAA/FDgalE='
        },
        body: JSON.stringify({
          origin_address: {
            city: 'London',
            postal_code: '10001',
            country_alpha2: originC,
            state: originC,
            line_1: '20 Bugsby\'s Way'
          },
          destination_address: {
            country_alpha2: desti,
            line_1: '67 Sultan Rd',
            state: 'Abuja',
            city: 'Abuja',
            postal_code: '90210'
          },
          incoterms: 'DDU',
          insurance: {is_insured: false, insured_currency: 'USD'},
          courier_selection: {show_courier_logo_url: true, apply_shipping_rules: true},
          shipping_settings: {units: {weight: percelWU, dimensions: percelDU}, output_currency: 'GBP'},
          parcels: [
            {
              box: {length: percelL, width: percelW, height: percelH},
              items: [
                {
                  quantity: 1,
                  category: percelCU,
                  declared_currency: 'USD',
                  declared_customs_value: 100
                }
              ],
              total_actual_weight: percelWt
            }
          ]
        })
      };
      
      
      fetch('https://api.easyship.com/2023-01/rates', options)
      .then(response => {
        // Check if the response is successful
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        
        // Parse the response body as JSON
        return response.json();
      })
      .then(data => {
        // Work with the parsed JSON data here
        // console.log(data);

        var outputBox = "";
    
        // Example: Update the DOM with the data
        for (let i = 0; i < data.rates.length; i++) {

          outputBox += "<tr><td class='logo-area'><img class = 'logo-img' src='" +data.rates[i].courier_logo_url+ "'></td><td class='time-area'>" + data.rates[i].min_delivery_time + "-" + data.rates[i].max_delivery_time + " working days</td><td class='tracking-ratings-area'>" + data.rates[i].tracking_rating + "</td><td class='ratings-area'>" + data.rates[i].delivery_time_rank + " <i class='fa-solid fa-star'></i></td><td class='handover-area'><div class='hanover-icon'><i class='fa fa-archive' aria-hidden='true'></i> " + data.rates[i].available_handover_options[0] + "</div><div class='hanover-icon'><i class='fa fa-truck' aria-hidden='true'></i> " + data.rates[i].available_handover_options[1] + "</div></td><td class='cost-area'>" + data.rates[i].currency + " " + data.rates[i].total_charge + "</td></tr>";
          
          
        }
        loadingSpinner.classList.add("hidden");
        document.getElementById("tbody_id").innerHTML = outputBox;
        // $("#tbody_id").html(outputBox);
      })
      .catch(error => {
        // Handle errors during the fetch operation
        console.error('Error during fetch operation:', error);
        loadingSpinner.classList.add("hidden");
        document.getElementById("tbody_id").innerHTML = '<div class="erorr text-center text-danger erorr-area">No Shipping Found!</>';
      });



      });

      // query ends
    //  country lists
      var settings = {
        "url": "https://api.easyship.com/2023-01/countries?page=1&per_page=100&continent=&alpha2=",
        "method": "GET",
        "timeout": 0,
        "headers": {
          "Authorization": "Bearer prod_vYG+WAAzcUI1YS6WUtm3FdxfPONsbqdHoyAA/FDgalE="
        },
      };
      
      var originOutput = "";
      var destinationOutput = "";

      $.ajax(settings).done(function (response) {
        // console.log(response);
        for (let index = 0; index < response.countries.length; index++) {
          // console.log(response.countries[index].name);
          if (response.countries[index].alpha2=="GB") {
            originOutput += "<option selected value='"+response.countries[index].alpha2+"'>"+response.countries[index].name+" ("+response.countries[index].alpha2+")</option>";
          }
          if (response.countries[index].alpha2=="NG") {
            destinationOutput += "<option selected value='"+response.countries[index].alpha2+"'>"+response.countries[index].name+" ("+response.countries[index].alpha2+")</option>";
          }
          originOutput += "<option value='"+response.countries[index].alpha2+"'>"+response.countries[index].name+" ("+response.countries[index].alpha2+")</option>";
          destinationOutput += "<option value='"+response.countries[index].alpha2+"'>"+response.countries[index].name+" ("+response.countries[index].alpha2+")</option>";

          
        }
      });


      var settings_2 = {
        "url": "https://api.easyship.com/2023-01/countries?page=2&per_page=100&continent=&alpha2=",
        "method": "GET",
        "timeout": 0,
        "headers": {
          "Authorization": "Bearer prod_vYG+WAAzcUI1YS6WUtm3FdxfPONsbqdHoyAA/FDgalE="
        },
      };
      
     

      $.ajax(settings_2).done(function (response) {
        // console.log(response);
        for (let index = 0; index < response.countries.length; index++) {
          // console.log(response.countries[index].name);
          if (response.countries[index].alpha2=="GB") {
            originOutput += "<option selected value='"+response.countries[index].alpha2+"'>"+response.countries[index].name+" ("+response.countries[index].alpha2+")</option>";
          }
          if (response.countries[index].alpha2=="NG") {
            destinationOutput += "<option selected value='"+response.countries[index].alpha2+"'>"+response.countries[index].name+" ("+response.countries[index].alpha2+")</option>";
          }
          originOutput += "<option value='"+response.countries[index].alpha2+"'>"+response.countries[index].name+" ("+response.countries[index].alpha2+")</option>";
          destinationOutput += "<option value='"+response.countries[index].alpha2+"'>"+response.countries[index].name+" ("+response.countries[index].alpha2+")</option>";

        }
      });



      var settings_3 = {
        "url": "https://api.easyship.com/2023-01/countries?page=3&per_page=100&continent=&alpha2=",
        "method": "GET",
        "timeout": 0,
        "headers": {
          "Authorization": "Bearer prod_vYG+WAAzcUI1YS6WUtm3FdxfPONsbqdHoyAA/FDgalE="
        },
      };
      
     

      $.ajax(settings_3).done(function (response) {
        // console.log(response);
        for (let index = 0; index < response.countries.length; index++) {
          // console.log(response.countries[index].name);
          if (response.countries[index].alpha2=="GB") {
            originOutput += "<option selected value='"+response.countries[index].alpha2+"'>"+response.countries[index].name+" ("+response.countries[index].alpha2+")</option>";
          }
          if (response.countries[index].alpha2=="NG") {
            destinationOutput += "<option selected value='"+response.countries[index].alpha2+"'>"+response.countries[index].name+" ("+response.countries[index].alpha2+")</option>";
          }
          originOutput += "<option value='"+response.countries[index].alpha2+"'>"+response.countries[index].name+" ("+response.countries[index].alpha2+")</option>";
          destinationOutput += "<option value='"+response.countries[index].alpha2+"'>"+response.countries[index].name+" ("+response.countries[index].alpha2+")</option>";

          $("#origin_country").html(originOutput);
          $("#destination_country").html(destinationOutput);
        }
        
      });


      


      var categories = {
        "url": "https://api.easyship.com/2023-01/item_categories",
        "method": "GET",
        "timeout": 0,
        "headers": {
          "Authorization": "Bearer prod_vYG+WAAzcUI1YS6WUtm3FdxfPONsbqdHoyAA/FDgalE="
        },
      };

      var categoriesOutput = "";
      $.ajax(categories).done(function (response) {
        // console.log(response);
        for (let index = 0; index < response.item_categories.length; index++) {
          // console.log(response.item_categories[index].name);
          if (response.item_categories[index].name == "Accessory (no-battery)") {
              categoriesOutput += "<option selected value='"+response.item_categories[index].name+"'>" + response.item_categories[index].name + "</option>";
          }
           categoriesOutput += "<option value='"+response.item_categories[index].name+"'>" + response.item_categories[index].name + "</option>";

            
          $("#percel_categories_unit").html(categoriesOutput);
        }
      });
      
     

     

      const options = {
        method: 'POST',
        headers: {
          accept: 'application/json',
          'content-type': 'application/json',
          authorization: 'Bearer prod_vYG+WAAzcUI1YS6WUtm3FdxfPONsbqdHoyAA/FDgalE='
        },
        body: JSON.stringify({
          origin_address: {
            city: 'London',
            postal_code: '10001',
            country_alpha2: 'GB',
            state: 'GB',
            line_1: '20 Bugsby\'s Way'
          },
          destination_address: {
            country_alpha2: 'NG',
            line_1: '67 Sultan Rd',
            state: 'Abuja',
            city: 'Abuja',
            postal_code: '90210'
          },
          incoterms: 'DDU',
          insurance: {is_insured: false, insured_currency: 'USD'},
          courier_selection: {show_courier_logo_url: true, apply_shipping_rules: true},
          shipping_settings: {units: {weight: 'kg', dimensions: 'cm'}, output_currency: 'GBP'},
          parcels: [
            {
              box: {length: 10, width: 5, height: 5},
              items: [
                {
                  quantity: 1,
                  category: 'Toys',
                  declared_currency: 'USD',
                  declared_customs_value: 100
                }
              ],
              total_actual_weight: 1
            }
          ]
        })
      };
      
      loadingSpinner.classList.remove("hidden");

      fetch('https://api.easyship.com/2023-01/rates', options)
      .then(response => {
        // Check if the response is successful
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        
        // Parse the response body as JSON
        return response.json();
      })
      .then(data => {
        // Work with the parsed JSON data here
        console.log(data);

        var outputBox = "";
    
        // Example: Update the DOM with the data
        for (let i = 0; i < data.rates.length; i++) {

          outputBox += "<tr><td class='logo-area'><img class = 'logo-img' src='" +data.rates[i].courier_logo_url+ "'></td><td class='time-area'>" + data.rates[i].min_delivery_time + "-" + data.rates[i].max_delivery_time + " working days</td><td class='tracking-ratings-area'>" + data.rates[i].tracking_rating + "</td><td class='ratings-area'>" + data.rates[i].delivery_time_rank + " <i class='fa-solid fa-star'></i></td><td class='handover-area'><div class='hanover-icon'><i class='fa fa-archive' aria-hidden='true'></i> " + data.rates[i].available_handover_options[0] + "</div><div class='hanover-icon'><i class='fa fa-truck' aria-hidden='true'></i> " + data.rates[i].available_handover_options[1] + "</div></td><td class='cost-area'>" + data.rates[i].currency + " " + data.rates[i].total_charge + "</td></tr>";
          
          
        }
        loadingSpinner.classList.add("hidden");
        document.getElementById("tbody_id").innerHTML = outputBox;
        // $("#tbody_id").html(outputBox);
      })
      .catch(error => {
        // Handle errors during the fetch operation
        console.error('Error during fetch operation:', error);
  
      });

     
  });

});

